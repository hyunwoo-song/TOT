from django.urls import path
from django.conf.urls import url
from . import views 
from django.conf.urls.static import static
from django.conf import settings

app_name = 'movies'

urlpatterns = [
    path('', views.list, name='list'),
    path('get_tmdb_movies/', views.get_tmdb_movies, name='get_tmdb_movies'),
    path('<int:movie_id>/', views.detail, name='detail'),
    path('<int:movie_id>/score/new/', views.comment_create, name='score_create'),
    path('<int:movie_id>/scores/<int:score_id>/update/', views.comment_update, name='score_update'),
    path('<int:movie_id>/scores/<int:score_id>/delete/', views.comment_delete, name='score_delete'),
    path('<int:movie_id>/like/', views.like, name='like'),
    path('recommendation/', views.recommendation, name='recommendation'),
    path('<int:user_id>/my_movie/', views.my_movie, name='my_movie'),
]