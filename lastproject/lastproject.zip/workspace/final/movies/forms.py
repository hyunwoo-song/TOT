from django import forms
from django.core.exceptions import ValidationError
from .models import Score

def min_length_3_validator(value):
    if len(value) < 5:
        raise forms.ValidationError(message='5글자 이상 입력해주세요')

class CommentForm(forms.ModelForm):
    SCORE_CHOICE = (
        ('1', '1점'),('2', '2점'),('3', '3점'),('4', '4점'),('5', '5점'),
        ('6', '6점'),('7', '7점'),('8', '8점'),('9', '9점'),('10', '10점'),
        )
    content = forms.CharField(label='', widget=forms.TextInput(attrs={'class':'form-control', 'placeholder':'댓글을 작성하세요.', 'size': '40'}),
    validators=[min_length_3_validator])
    value = forms.ChoiceField(label='',widget=forms.Select(), choices=SCORE_CHOICE)
    class Meta:
        model = Score
        fields = ['content', 'value']