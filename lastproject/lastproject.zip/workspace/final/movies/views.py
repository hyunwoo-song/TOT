from django.shortcuts import render, redirect, get_object_or_404
import os, requests
import json
from django.http import JsonResponse
from .models import Movie, Score, Genre
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST
from collections import OrderedDict
from .forms import CommentForm
from django.contrib import messages
from django.conf import settings
import random
from accounts.models import User

def list(request):
    movies = Movie.objects.all()
    q = request.GET.get('search_content', '')
    if q:
        movies = movies.filter(title__contains=q)
    return render(request, 'movies/index.html', {'movies':movies})

def detail(request, movie_id):
    movie = get_object_or_404(Movie, id=movie_id)
    video = requests.get('https://api.themoviedb.org/3/movie/'+str(movie.movieId)+'/videos?api_key=f3d66cf075ca2d688fbccb45f5d91b4b&language=en-US').json()
    video_url = 'ARYO8cCgP74' # default url
   
    if video['results']:
        video_url = video['results'][0]['key']
    comment_form = CommentForm()
    avg_score = 0
    scores = 0
    cnt = 0
    if movie.score_set.all():
        for comment in movie.score_set.all():
            scores += comment.value
            cnt += 1
        avg_score = round((movie.vote_count*movie.vote_average+scores)/(movie.vote_count+cnt), 1)
        movie.vote_average = avg_score
        movie.save()
    actor_data = requests.get('https://api.themoviedb.org/3/movie/'+str(movie.movieId)+'/credits?api_key=f3d66cf075ca2d688fbccb45f5d91b4b').json()
    actors = []
    for j in range(len(actor_data["cast"])):
        if j >=6: continue
        actors.append(actor_data["cast"][j])
    
    for crew in actor_data['crew']:
        if crew['job'] == "Director":
            director = crew['name']
    return render(request, 'movies/index3.html', {'movie': movie, 'comment_form': comment_form, 'video_url': video_url, 'video': video, 'avg_score': avg_score, 'actors': actors, 'director': director })

@login_required
@require_POST
def comment_create(request, movie_id):
    comment_form = CommentForm(request.POST)
    if comment_form.is_valid():
        comment = comment_form.save(commit=False)
        comment.user = request.user
        comment.movie_id = movie_id
        comment.save()
    else:
        messages.error(request, "Error!")
    return redirect('movies:detail', movie_id)
    
@login_required
def comment_delete(request, movie_id, score_id):
    comment = get_object_or_404(Score, id=score_id)
    if request.user == comment.user:
        comment.delete()
    return redirect('movies:detail', movie_id)

@login_required
def comment_update(request, movie_id, score_id):
    comment = get_object_or_404(Score, id=score_id)
    if request.method == 'POST':
        form = CommentForm(request.POST, instance = comment)
        if form.is_valid():
            form.save()
            return redirect('movies:detail', movie_id)
    else:
        form = CommentForm(instance=comment)
        print(form)
    return render(request, 'movies/form.html', {'form': form})

@login_required
def like(request, movie_id):
    movie = get_object_or_404(Movie, id=movie_id)
    # 좋아요를 누른 사람중에 자기자신이 있으면 취소를 해서 없애버림
    if request.user in movie.like_users.all():
        # 2. 좋아요 취소
        movie.like_users.remove(request.user)
        liked = False
    # 1. 좋아요 !
    # 좋아요를 누른 사람에 현재 유저를 추가
    else:
        movie.like_users.add(request.user)
        liked = True
    return JsonResponse({'liked': liked, 'count': movie.like_users.count()})
    
@login_required
def recommendation(request):
    movies = Movie.objects.all()
    like_movies = request.user.like_movies.all()
    favorite_genres = dict()
    rand = random.sample(range(1, len(movies)), 12)
    
    recommended_movie = []
    
    if like_movies:
        for movie in like_movies:
            for g in movie.genre.all():
                if favorite_genres.get(g):
                    favorite_genres[g] += 1
                else:
                    favorite_genres[g] = 1
        Max = max(favorite_genres.values())
        max_index = None
        for key in favorite_genres:
            if favorite_genres[key] == Max:
                max_index = key 
        favorite_genre = max_index
        
        for movie in movies:
            if len(recommended_movie) > 12: break
            for g in movie.genre.all():
                if favorite_genre == g:
                    recommended_movie.append(movie)
                    break
    else:
        for m_id in rand:
            movie = get_object_or_404(Movie, id=m_id)
            recommended_movie.append(movie)
    return render(request, 'movies/recommendation.html', {'like_movies': like_movies, 'rand': rand, 'recommended_movie':recommended_movie})
    
@login_required
def my_movie(request, user_id):
    user = get_object_or_404(User, id=user_id)
    if request.user == user:
        like_movies = request.user.like_movies.all()
        user = request.user
    else:
        like_movies = user.like_movies.all()
    
    return render(request, 'movies/mymovie.html', {'like_movies': like_movies, 'user':user})

def get_tmdb_movies(request):
    genre_json = requests.get('https://api.themoviedb.org/3/genre/movie/list', params={'api_key': 'f3d66cf075ca2d688fbccb45f5d91b4b', 
        'language': 'ko-KR' }).json()
    
    genre_data = []
    # with open('movies/fixtures/genre.json', 'w', encoding='utf-8') as make_file:
    #     json.dump(genre_json, make_file, ensure_ascii=False, indent="\t")
    
    """
    CREATE GENRE.JSON, OURMOVIE.JSON 
    """
    for j in range(len(genre_json['genres'])):   
        data = genre_json['genres'][j]
        genre=dict()
        genre.update({'pk':j+1})
        genre.update({'model': "movies.genre"})
        fields = dict()
        fields['id'] = data['id']
        fields['name'] = data['name']
        genre['fields'] = fields
        genre_data.append(genre)
    with open('movies/fixtures/genre.json', 'w', encoding='utf-8') as make_file:
        json.dump(genre_data, make_file, ensure_ascii=False, indent="\t")
    #
    
    movie_data = []
    actor_data = []
    pk = 0
    for p in range(1, 5):
        movie_json = requests.get('https://api.themoviedb.org/3/movie/now_playing', params={'api_key': 'f3d66cf075ca2d688fbccb45f5d91b4b', 
        'language': 'ko-KR', 'page': str(p)}).json()
       
        for i in range(len(movie_json['results'])):
            movie = dict()
            data = movie_json['results'][i]
            pk = (i+1)+(p-1)*10
            movie.update({'pk':pk})
            movie.update({'model': "movies.movie"})
            
            fields = dict()
            fields.update({'title': data['title']})
            fields.update({'vote_count': data['vote_count']})
            fields.update({'vote_average': data['vote_average']})
            fields.update({'title': data['title']})
            fields.update({'movieId': data['id']})
            fields.update({'poster_url': data['poster_path']})
            fields.update({'description': data['overview']})
            fields.update({'genre' : data['genre_ids']})
            fields.update({'popularity': data['popularity']})
            
            movieId = data['id']
            movie_images = requests.get('https://api.themoviedb.org/3/movie/'+str(movieId)+'/images?api_key=f3d66cf075ca2d688fbccb45f5d91b4b').json()
            
            if movie_images['backdrops']:
                fields.update({'image_url': movie_images['backdrops'][0]['file_path']})
            else:
                
                continue
            movie_detail = requests.get('https://api.themoviedb.org/3/movie/'+str(movieId), params={'api_key': '7e320336536fad2590fcd5d26710954b', 'languag': 'ko-KR'}).json()
            fields.update({'title_en': movie_detail["original_title"]})
            fields.update({'open_date': movie_detail["release_date"]})
            fields.update({'revenue': movie_detail["revenue"]})
            fields.update({'runtime': movie_detail['runtime']})
            # actors = requests.get('https://api.themoviedb.org/3/movie/'+str(movieId)+'/credits?api_key=f3d66cf075ca2d688fbccb45f5d91b4b').json()
            # actor = dict()
            movie.update({'fields': fields})
            movie_data.append(movie)
    
    
    with open('movies/fixtures/ourmovie.json', 'w', encoding='utf-8') as make_file:
        json.dump(movie_data, make_file, ensure_ascii=False, indent="\t")
        
    return render( request, 'get_movie.html', {'movie_data': movie_data, 'genre_json': genre_json} )
    