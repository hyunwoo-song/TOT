from django.db import models
from django.conf import settings


class Genre(models.Model):
    name = models.CharField(max_length=20)
    def __str__(self):
        return self.name

class Movie(models.Model):
    title = models.CharField(max_length=30, null=True, blank=True)
    movieId = models.IntegerField(null=True, blank=True)
    vote_count = models.IntegerField(null=True, blank=True)
    vote_average = models.FloatField(null=True, blank=True)
    #audience = models.IntegerField()
    poster_url = models.TextField(null=True, blank=True)
    image_url = models.TextField(null=True, blank=True)
    # poster_url_2 = models.TextField(null=True, blank=True)
    # poster_url_3 = models.TextField(null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    genre = models.ManyToManyField(Genre, related_name='genre_movie', null=True, blank=True)
    popularity = models.IntegerField(null=True, blank=True)
    
    title_en = models.CharField(max_length=50, null=True, blank=True)
    open_date = models.DateField(null=True, blank=True)
    revenue = models.IntegerField(null=True, blank=True)
    runtime = models.IntegerField(null=True, blank=True)
    like_users = models.ManyToManyField(settings.AUTH_USER_MODEL, related_name='like_movies', blank=True)
	#movie : genre = 1 : N
    
class Score(models.Model):
    content = models.CharField(max_length=100)
    value = models.IntegerField()
    movie = models.ForeignKey(Movie, on_delete=models.CASCADE)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True) # create 될때, 딱 한번 현재 시각
    #score : user = M: N
    

