const app = new Vue({
  delimiters: ['[[',']]'],
  el: "#app",
  data: {
      movies: [
          
          ],
      movieDetail: {},  // 상세 화면에서 출력할 때 사용할 영화 객체입니다.
  },
})
          