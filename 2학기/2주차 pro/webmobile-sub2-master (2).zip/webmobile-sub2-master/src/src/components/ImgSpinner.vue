<template>
  <RotateSquare5 />
</template>

<script>
import { RotateSquare5 } from "vue-loading-spinner";
export default {
  components: {
    RotateSquare5
  }
};
</script>
