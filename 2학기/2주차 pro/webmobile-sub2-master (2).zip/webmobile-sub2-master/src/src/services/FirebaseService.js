import firebase from "firebase/app";
import "firebase/firestore";
import "firebase/auth";
//Test
const POSTS = "posts";
const PORTFOLIOS = "portfolios";

// Setup Firebase
const config = {
  projectId: "webmobile-sub2-b231d",
  authDomain: "webmobile-sub2-b231d.firebaseapp.com",
  apiKey: "AIzaSyCwYm1henJzycD1wZeYFtc8CuYyDYYXy4Y",
  databaseURL: "https://webmobile-sub2-b231d.firebaseio.com/",
  storageBucket: "webmobile-sub2-b231d.appspot.com",
  messagingSenderId: "257713723263",
  appId: "1:257713723263:web:ed84d2ee321bdd21"
};

firebase.initializeApp(config);
const firestore = firebase.firestore();

export default {
  getPosts() {
    const postsCollection = firestore.collection(POSTS);
    return postsCollection
      .orderBy("created_at", "desc")
      .get()
      .then(docSnapshots => {
        return docSnapshots.docs.map(doc => {
          let data = doc.data();
          data.created_at = new Date(data.created_at.toDate());
          return data;
        });
      });
  },
  postPost(title, body) {
    return firestore.collection(POSTS).add({
      title,
      body,
      created_at: firebase.firestore.FieldValue.serverTimestamp()
    });
  },
  getPortfolios() {
    const postsCollection = firestore.collection(PORTFOLIOS);
    return postsCollection
      .orderBy("created_at", "desc")
      .get()
      .then(docSnapshots => {
        return docSnapshots.docs.map(doc => {
          let data = doc.data();
          data.created_at = new Date(data.created_at.toDate());
          return data;
        });
      });
  },
  postPortfolio(title, body, img) {
    return firestore.collection(PORTFOLIOS).add({
      title,
      body,
      img,
      created_at: firebase.firestore.FieldValue.serverTimestamp()
    });
  },
  loginWithGoogle() {
    let provider = new firebase.auth.GoogleAuthProvider();
    return firebase
      .auth()
      .signInWithPopup(provider)
      .then(function(result) {
        let accessToken = result.credential.accessToken;
        let user = result.user;
        return result;
      })
      .catch(function(error) {
        console.error("[Google Login Error]", error);
      });
  }
};
