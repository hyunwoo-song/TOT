module.exports = {
  STATION_DATA: [{
      line: "1호선",
      imgURL: "1.svg"
    },
      {
      line: "2호선",
      imgURL: "2.svg"
    },
          {
      line: "3호선",
      imgURL: "3.svg"
    },
                      {
      line: "4호선",
      imgURL: "4.svg"
    },
                      {
      line: "5호선",
      imgURL: "5.svg"
    },
                      {
      line: "6호선",
      imgURL: "6.svg"
    },
                      {
      line: "분당선",
      imgURL: "bundang.png"
    },
                      {
      line: "7호선",
      imgURL: "7.svg"
    },
                      {
      line: "8호선",
      imgURL: "8.svg"
    },
                      {
      line: "신분당선",
      imgURL: "sinbundang.png"
    },
                      {
      line: "9호선",
      imgURL: "9.svg"
    },
                      {
      line: "공항철도",
      imgURL: "air.svg"
    },
                {
      line: "경의중앙선",
      imgURL: "ang.png"
    },
                 
                       {
      line: "경춘선",
      imgURL: "choon.png"
    },
                 
                  {
      line: "수인선",
      imgURL: "suin.png"
    },
  ]
}

