import webbrowser
keywords = ['날씨','아이유','구미 맛집']   
for k in keywords:
	webbrowser.open('https://search.daum.net/search?q=' + k)
