from django.shortcuts import render, redirect, get_object_or_404
from .models import Movie, Score
from .forms import ScoreForm
# Create your views here.

def list(request):
    movies = Movie.objects.all()
    return render(request,'list.html', {'movies':movies})
    
def detail(request, movie_id):
    movie = Movie.objects.get(pk=movie_id)
    scores_form = ScoreForm()
    return render(request, 'detail.html', {'movie':movie, 'scores_form': scores_form})
    
def delete(request, movie_id):
    movie = get_object_or_404(Movie, id=movie_id)
    movie.delete()
    return redirect('movies:list')

def scores_new(request, movie_id):
    scores_form = ScoreForm(request.POST)
    if scores_form.is_valid():
        score = scores_form.save(commit=False)
        score.movie_id = movie_id
        score.save()
    return redirect('movies:detail', movie_id)
    
def scores_delete(request, movie_id, score_id):
    score = get_object_or_404(Score, id=score_id)
    score.delete()
    return redirect('movies:detail', movie_id)
    