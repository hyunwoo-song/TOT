from django.urls import path
from . import views

app_name ='movies'

urlpatterns=[
    path('', views.list, name='list'),
    path('<int:movie_id>/detail/', views.detail, name='detail'),
    path('<int:movie_id>/delete/', views.delete, name='delete'),
    path('<int:movie_id>/scores/new/', views.scores_new, name='scores_new'),
    path('<int:movie_id>/scores/<int:score_id>/delete/', views.scores_delete, name='scores_delete'),
    ]