from django import forms
from .models import Score

class ScoreForm(forms.ModelForm):
    score = forms.IntegerField(label='', widget=forms.TextInput(attrs={'class':'form-control','placeholder':'평점을 작성하세요'}))
    content = forms.CharField(label='', widget=forms.TextInput(attrs={'class':'form-control','placeholder':'한줄평을 작성하세요'}))
    class Meta:
        model = Score
        fields = ['score','content',]