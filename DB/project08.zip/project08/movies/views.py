from django.shortcuts import render, redirect
from .models import Movie
from .forms import ScoreForm, MovieForm
# from .forms import MovieForm
# # Create your views here.

def list(request):
    movies = Movie.objects.all()
    return render(request,'list.html', {'movies':movies})
    
def detail(request, movie_id):
    movie = Movie.objects.get(pk=movie_id)
    scores_form = ScoreForm()
    return render(request, 'detail.html', {'movie':movie, 'scores_form':scores_form})
    
def new(request):
    movies_form = MovieForm(request.POST)
    if movies_form.is_valid():
        movie = movies_form.save()
        movie.save()
        return redirect('/movies/{}'.format(movie.id))
    return render(request, 'form.html', {'movies_form':movies_form})
    
def edit(request, movie_id):
    movie= Movie.objects.get(pk=movie_id)
    if request.method=='POST':
        movies_form = MovieForm(request.POST, instance= movie)
        if movies_form.is_valid():
            movies_form.save()
            return redirect('movies:list')
    else:
        movies_form=MovieForm(instance=movie)
        
    return render(request, 'form.html', {'movies_form':movies_form})